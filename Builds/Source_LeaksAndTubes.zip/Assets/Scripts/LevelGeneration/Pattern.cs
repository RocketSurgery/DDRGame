using UnityEngine;
using System.Collections;

public class Pattern : MonoBehaviour 
{
	public int width = 12;
	public int height = 12;
	public bool[] patternSquare = new bool[4];

	void Update ()
	{
	
	}
}
